What contains this folders?
===========================

This folder contains attacks for some vulnerabilities of the vulnerable application.  